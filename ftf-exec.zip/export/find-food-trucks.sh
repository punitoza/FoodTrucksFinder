dir=.
jar_name=food-trucks-finder-0.0.1-SNAPSHOT.jar
java -jar food-trucks-finder-0.0.1-SNAPSHOT.jar
